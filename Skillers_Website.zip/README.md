# Skillers Website

A responsive Skillers landing website inspired by the supplied brand reference.

## Included
- Responsive Home / Hero section
- Courses section
- About / Why Skillers
- Blog section
- FAQ
- Contact CTA
- Mobile navigation
- Skillers blue + orange visual identity
- Supplied reference image in `assets/skillers-brand-reference.png`

## Run
Open `index.html` in a browser.

## Replace before launch
- Course prices and descriptions
- Email / phone number
- Course checkout links
- Real photos and course thumbnails
- Social media links
- Logo SVG/PNG if you have the official source file
